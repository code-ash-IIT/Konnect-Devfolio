package com.example.konnect

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton

class Profile : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)


        val Worker_Plumber: ImageButton = findViewById(R.id.Worker_Plumber)
        Worker_Plumber.setOnClickListener {
            val intent = Intent(this, Worker2::class.java)
            startActivity(intent)
        }
        val Worker_Electrician: ImageButton = findViewById(R.id.Worker_Electrician)
        Worker_Electrician.setOnClickListener {
            val intent = Intent(this, Worker2::class.java)
            startActivity(intent)
        }
        val Worker_Mechanic: ImageButton = findViewById(R.id.Worker_Mechanic)
        Worker_Mechanic.setOnClickListener {
            val intent = Intent(this, Worker2::class.java)
            startActivity(intent)
        }
        val Worker_Barber: ImageButton = findViewById(R.id.Worker_Barber)
        Worker_Mechanic.setOnClickListener {
            val intent = Intent(this, Worker2::class.java)
            startActivity(intent)
        }
        val Worker_PestConrol: ImageButton = findViewById(R.id.Worker_PestControl)
        Worker_PestConrol.setOnClickListener {
            val intent = Intent(this, Worker2::class.java)
            startActivity(intent)
        }
        val Worker_AcRepair: ImageButton = findViewById(R.id.Worker_AcRepair)
        Worker_PestConrol.setOnClickListener {
            val intent = Intent(this, Worker2::class.java)
            startActivity(intent)
        }
    }

}
