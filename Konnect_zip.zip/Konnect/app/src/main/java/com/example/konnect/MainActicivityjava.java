package com.example.konnect;

public class MainActicivityjava {
}
