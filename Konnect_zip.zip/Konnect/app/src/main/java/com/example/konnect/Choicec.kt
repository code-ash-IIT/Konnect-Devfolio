package com.example.konnect

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Choicec : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_choicec)
    }
}