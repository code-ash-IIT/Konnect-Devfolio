package com.example.konnect;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class services1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_services1);
        ImageButton button = (ImageButton) findViewById(R.id.acrepair);
        ImageButton button2 = (ImageButton) findViewById(R.id.plumber);
        ImageButton button3 = (ImageButton) findViewById(R.id.electrician);
        ImageButton button4 = (ImageButton) findViewById(R.id.mechanic);
        ImageButton button5 = (ImageButton) findViewById(R.id.pestcontrol);
        ImageButton button6 = (ImageButton) findViewById(R.id.barber);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openLocation();
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openLocation();
            }
        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openLocation();
            }
        });
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openLocation();
            }
        });
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openLocation();
            }
        });
        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openLocation();
            }
        });

    }
    public void openLocation() {
        Intent intent = new Intent(this, Customer2.class);
        startActivity(intent);
    }
    }
